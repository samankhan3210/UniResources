#include<stdio.h>
#include<string.h>
int main()
{
	char a[500],b;
	int i=0,j=0;
	printf("Enter a string:");
	gets(a);
	printf("\nBefore Reverse: %s",a);
	j=strlen(a)-1;
	for(i=0;i<j;i++)
	{
		b=a[i];
		a[i]=a[j];
		a[j]=b;
		j--;
	}
	printf("\nAfter Reverse: %s",a);
}

