#include<stdio.h>
#include<string.h>
int main()
{
	char a[100];
	int i=0;
	printf("Enter a string:");
	gets(a);
	while(a[i]!='\0')
	{
		i++;
	}
	printf("The lenght of the string is %d",i);
}
