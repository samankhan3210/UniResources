#include<stdio.h>
#include<string.h>
int main()
{
	char st[60];
	int i=0,j;
	printf("Enter the sentence:");
	gets(st);
	for(i=0;st[i]!='\0';i++)
	{
		j=i;
		if(st[i]=='a'||st[i]=='A'||st[i]=='e'||st[i]=='E'||st[i]=='i'||st[i]=='I'||st[i]=='o'||st[i]=='O'||st[i]=='u'||st[i]=='U')
		{
			for(j=i;st[j]!='\0';j++)
		    {
		    	st[j]=st[j+1];
			}	
		}
	}
	printf("Sentence after deleting the vowels:%s",st);
}
