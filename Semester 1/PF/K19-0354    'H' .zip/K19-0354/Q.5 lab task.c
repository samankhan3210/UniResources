#include<stdio.h>
#include<string.h>
int main()
{
	char a[100];
	int i,p,n;
	printf("Enter a string:");
	gets(a);
	printf("Enter the position you want text to be extracted from: ");
	scanf("%d",&p);
	printf("Enter the number of characters you want extracted: ");
	scanf("%d",&n);
	for(i=p-1;i<n+p;i++)
	{
	printf("%c",a[i]);	
}
}
