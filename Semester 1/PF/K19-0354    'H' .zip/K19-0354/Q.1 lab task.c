#include<stdio.h>
#include<string.h>
int main()
{
	char a[100];
	printf("Enter a string:");
	gets(a);
	printf("\nBefore Reverse: %s",a);
	strrev(a);
	printf("\nAfter Reverse: %s",a);
}
